import unittest
from speedconvert.converter import SpeedConverter

class TestSpeedConverter(unittest.TestCase):
    def setUp(self):
        self.converter = SpeedConverter()

    def test_kmh_to_mph(self):
        self.assertAlmostEqual(self.converter.kmh_to_mph(100), 62.1371, places=4)

    def test_mph_to_kmh(self):
        self.assertAlmostEqual(self.converter.mph_to_kmh(60), 96.5606, places=4)

if __name__ == "__main__":
    unittest.main()
