"""
exceptions.py - Custom exceptions for SpeedConvert
"""
class SpeedConvertError(Exception):
    """Base exception for speed conversion errors."""
    pass
