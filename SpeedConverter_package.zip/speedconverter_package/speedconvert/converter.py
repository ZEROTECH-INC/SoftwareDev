"""
converter.py - Core speed conversion logic
"""
class SpeedConverter:
    """Class for converting speeds between units."""
    
    def kmh_to_mph(self, kmh: float) -> float:
        """Convert kilometers per hour to miles per hour."""
        return kmh * 0.621371

    def mph_to_kmh(self, mph: float) -> float:
        """Convert miles per hour to kilometers per hour."""
        return mph / 0.621371

    def ms_to_kmh(self, ms: float) -> float:
        """Convert meters per second to wkilometers per hour."""
        return ms * 3.6

    def kmh_to_ms(self, kmh: float) -> float:
        """Convert kilometers per hour to meters per second."""
        return kmh / 3.6

    def ms_to_mph(self, ms: float) -> float:
        """Convert meters per second to miles per hour."""
        return ms * 2.23694

    def mph_to_ms(self, mph: float) -> float:
        """Convert miles per hour to meters per second."""
        return mph / 2.23694
