"""
SpeedConvert package initialization.
"""
from .converter import SpeedConverter
