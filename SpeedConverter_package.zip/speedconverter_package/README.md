# SpeedConvert

A simple Python package for converting speeds between m/s, km/h, and mph.